"use client"

import type React from "react"

import { useState } from "react"
import { Camera, Upload, Loader2, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function MathSolverApp() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [solution, setSolution] = useState<string | null>(null)

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string)
        setSolution(null)
      }
      reader.readAsDataURL(file)
    }
  }

  const solveProblem = async () => {
    if (!selectedImage) return

    setIsProcessing(true)

    // Simulate AI processing
    setTimeout(() => {
      setSolution(`
        \\text{Given: } 2x + 5 = 13
        
        \\text{Step 1: Subtract 5 from both sides}
        2x + 5 - 5 = 13 - 5
        2x = 8
        
        \\text{Step 2: Divide both sides by 2}
        \\frac{2x}{2} = \\frac{8}{2}
        x = 4
        
        \\text{Solution: } x = 4
      `)
      setIsProcessing(false)
    }, 2000)
  }

  const resetApp = () => {
    setSelectedImage(null)
    setSolution(null)
    setIsProcessing(false)
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-2 pt-8">
          <h1 className="text-3xl font-bold text-foreground text-balance">Math Problem Solver</h1>
          <p className="text-muted text-pretty">Upload an image of your math problem and get step-by-step solutions</p>
        </div>

        {/* Upload Section */}
        {!selectedImage && (
          <Card className="border-2 border-dashed border-border hover:border-accent transition-colors">
            <CardContent className="p-12">
              <div className="text-center space-y-6">
                <div className="mx-auto w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center">
                  <Camera className="w-8 h-8 text-accent" />
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-semibold text-card-foreground">Upload Math Problem</h3>
                  <p className="text-muted text-sm">Take a photo or upload an image of your math problem</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    className="bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={() => document.getElementById("camera-input")?.click()}
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Take Photo
                  </Button>

                  <Button variant="outline" onClick={() => document.getElementById("file-input")?.click()}>
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Image
                  </Button>
                </div>

                <input
                  id="camera-input"
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleImageUpload}
                  className="hidden"
                />

                <input id="file-input" type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Image Preview & Processing */}
        {selectedImage && (
          <Card>
            <CardContent className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-card-foreground">Uploaded Problem</h3>

                <div className="relative">
                  <img
                    src={selectedImage || "/placeholder.svg"}
                    alt="Math problem"
                    className="w-full max-h-64 object-contain rounded-lg border border-border"
                  />
                </div>
              </div>

              <div className="flex gap-3">
                {!solution && !isProcessing && (
                  <Button onClick={solveProblem} className="bg-accent hover:bg-accent/90 text-accent-foreground flex-1">
                    Solve Problem
                  </Button>
                )}

                <Button variant="outline" onClick={resetApp} disabled={isProcessing}>
                  Upload New
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Processing State */}
        {isProcessing && (
          <Card>
            <CardContent className="p-8">
              <div className="text-center space-y-4">
                <Loader2 className="w-8 h-8 animate-spin text-accent mx-auto" />
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold text-card-foreground">Solving Problem...</h3>
                  <p className="text-muted text-sm">
                    AI is analyzing your math problem and generating step-by-step solutions
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Solution Display */}
        {solution && !isProcessing && (
          <Card>
            <CardContent className="p-6 space-y-6">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <h3 className="text-lg font-semibold text-card-foreground">Solution</h3>
              </div>

              <div className="bg-muted/20 rounded-lg p-6">
                <div className="text-card-foreground leading-relaxed">
                  {/* LaTeX would be rendered here with a library like KaTeX */}
                  <div className="font-mono text-sm whitespace-pre-line">
                    {solution.split("\\text{").map((part, index) => {
                      if (index === 0) return part
                      const [text, ...rest] = part.split("}")
                      return (
                        <span key={index}>
                          <span className="font-sans font-medium">{text}</span>
                          {rest.join("}")}
                        </span>
                      )
                    })}
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={resetApp} className="flex-1 bg-transparent">
                  Solve Another Problem
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
